Upload index.html to the root of your public GitHub repository.
Then enable GitHub Pages from Settings > Pages > Deploy from branch > main / root.
